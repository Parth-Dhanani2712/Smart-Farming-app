package com.example.farmsapp;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
