import 'package:farmsapp/mainpage/Expance%20Tracker/pages/home_page.dart';
import 'package:flutter/material.dart';

class tracker extends StatelessWidget {
  const tracker({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Expense Tracker'),
        ),
      body: abc(),
    );
  }
}

class abc extends StatefulWidget {
  const abc({super.key});

  @override
  State<abc> createState() => _abcState();
}

class _abcState extends State<abc> {
  @override
  Widget build(BuildContext context) {
    return HomePage();
  }
}
