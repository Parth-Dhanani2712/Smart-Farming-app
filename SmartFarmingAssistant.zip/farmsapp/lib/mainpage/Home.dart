import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:farmsapp/mainpage/weather/weather.dart';
import 'Expance Tracker/tracker.dart';
import 'comunity forum/forum.dart';
import 'cropinfo/cropinfo.dart';
import 'market/market.dart';


class IconGrid extends StatefulWidget {
  @override
  State<IconGrid> createState() => _IconGridState();
}

class _IconGridState extends State<IconGrid> {

  // sign user out
  void signOut() {
    FirebaseAuth.instance.signOut();
  }
  final List<String> customIcons = [
    'assets/weather-forecast-c.png',
    'assets/crop-c.png',
    'assets/market-c.png',
    'assets/Expense-c.png',
    'assets/community-c.png',
    ];

  final List<String> customIconsName = [
    "Weather Forecasting",
    "Crop Information",
    "Market Place",
    "Expense Tracker",
    "Community Forum ",
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        centerTitle: true,
        actions: [
          // sign out button
          IconButton(
            onPressed: signOut,
            icon: Icon(Icons.logout),
          ),
        ],
      ),

      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
        ),
        itemCount: customIcons.length,
        itemBuilder: (context, index) {
          return Column(
            children: [
              IconButton(
                icon: Image.asset(
                  customIcons[index],
                  width: 150.0,
                  height: 150.0,
                ),
                onPressed: () {
                  switch (index) {
                    case 0:
                      Navigator.push(context, MaterialPageRoute(builder: (context) => weather()));
                      break;
                    case 1:
                      Navigator.push(context, MaterialPageRoute(builder: (context) => cropinfo()));
                      break;
                    case 2:
                      Navigator.push(context, MaterialPageRoute(builder: (context) => market()));
                      break;
                    case 3:
                      Navigator.push(context, MaterialPageRoute(builder: (context) => tracker()));
                      break;
                    case 4:
                      Navigator.push(context, MaterialPageRoute(builder: (context) => forum()));
                      break;
                  // Add cases for other icons/pages as needed
                  }
                  print('Button $index pressed');
                },
              ),
              Text(customIconsName[index],
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,

              ),
              ),
            ],
          );
        },
      ),
    );
  }
}