import 'package:farmsapp/mainpage/comunity%20forum/pages/home_page.dart';
import 'package:flutter/material.dart';

class forum extends StatelessWidget {
  const forum({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: HomePage(),
      );
  }
}
