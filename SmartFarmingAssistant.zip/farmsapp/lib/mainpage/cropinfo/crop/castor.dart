import 'package:flutter/material.dart';

class castor extends StatelessWidget {
  const castor({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Castor"),),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Image.asset(
                    "assets/seed.png",
                    width: 100,
                    height: 100,
                  )),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Requirement', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text(
                'Choose the Right Location:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Castor plants prefer warm climates and well-drained soil. Select a location with full sun exposure.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Prepare the Soil:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Ensure the soil is loose, well-draining, and rich in organic matter. You can improve soil quality by adding compost or aged manure.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Sow the Seeds:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Plant castor seeds directly in the ground after the last frost date. Plant them about 1 inch deep and space them 3 to 4 feet apart.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Watering:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the soil consistently moist but not waterlogged. Water deeply once or twice a week, especially during dry periods.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Fertilize:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Use a balanced fertilizer or a fertilizer high in nitrogen to promote healthy growth. Apply fertilizer according to the package instructions.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Mulching:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Mulch around the base of the plants to retain moisture, suppress weeds, and protect the roots.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Support if Needed:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'As castor plants grow tall, you may need to provide support in the form of stakes or a trellis to prevent them from falling over.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pest and Disease Control:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep an eye out for pests like aphids, caterpillars, and spider mites. Use organic pest control methods if needed. Monitor for any signs of diseases such as fungal infections and treat promptly.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Castor plants typically mature in about 3 to 5 months. Harvest the seed pods when they turn brown and begin to split open. Wear gloves when handling the pods as they can be prickly.',
                style: TextStyle(fontSize: 16),
              ),

              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Precautions and Requirements', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text(
                'Precautions:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Toxicity: All parts of the castor plant, especially the seeds, contain ricin, a toxic compound. Handle the plant with care and keep it away from children and pets.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Skin Protection:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'When working with castor plants, wear gloves and long sleeves to avoid skin irritation.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Proper Disposal:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Dispose of any plant parts, especially seeds, properly to prevent accidental ingestion by humans or animals.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Requirements:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Climate: Castor plants thrive in warm climates with temperatures above 60°F (15°C). They are sensitive to frost.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Soil:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Well-drained soil with a pH range of 5.5 to 6.5 is ideal for castor plants. They do well in sandy or loamy soils.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Water:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Adequate watering is crucial, especially during the plant\'s establishment phase and periods of drought.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Sunlight:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Full sun exposure is essential for optimal growth and seed production.',
                style: TextStyle(fontSize: 16),
              ),

          ],
          ),
        ),
      ),
    );
  }
}
