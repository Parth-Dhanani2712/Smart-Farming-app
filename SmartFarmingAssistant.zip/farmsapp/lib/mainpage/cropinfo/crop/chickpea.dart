import 'package:flutter/material.dart';

class chickpea extends StatelessWidget {
  const chickpea({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Chickpea")),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Image.asset(
                    "assets/chickpeas.png",
                    width: 100,
                    height: 100,
                  )),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Requirement', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text(
                'Climate and Soil Requirements:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Chickpeas thrive in warm climates with well-drained, sandy-loam soil.\n'
                    'The pH level of the soil should ideally be between 6.0 and 7.5.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Site Selection:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Choose a sunny location for planting chickpeas as they require at least 6-7 hours of sunlight daily.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Seed Selection and Preparation:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Select high-quality chickpea seeds from a reputable source.\n'
                    'Soak the seeds in water overnight before planting to improve germination rates.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Planting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Plant chickpea seeds directly into the soil at a depth of around 2-3 inches.\n'
                    'Space the seeds approximately 4-6 inches apart in rows that are 18-24 inches apart.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Watering:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Water the chickpea plants regularly, especially during dry periods, to ensure proper growth.\n'
                    'Avoid overwatering as it can lead to diseases like root rot.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Fertilization:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Use a balanced fertilizer or compost to provide nutrients to the plants.\n'
                    'Apply the fertilizer according to the instructions on the package.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Weed Control:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the area around the chickpea plants free from weeds to reduce competition for nutrients and water.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pest and Disease Management:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Monitor the plants regularly for pests such as aphids, cutworms, and leaf miners.\n'
                    'Use organic pest control methods or suitable insecticides if necessary.\n'
                    'Watch out for diseases like fusarium wilt and ascochyta blight and take preventive measures such as crop rotation.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Support and Pruning:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Some chickpea varieties may benefit from support such as trellises or stakes.\n'
                    'Prune any damaged or diseased parts of the plants to promote healthy growth.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Chickpeas are ready for harvest when the pods turn brown and dry on the plant.\n'
                    'Harvest the pods by hand and remove the chickpeas from the pods.\n'
                    'Allow the chickpeas to dry further in a well-ventilated area before storage.',
                style: TextStyle(fontSize: 16),
              ),

              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Precautions and Requirements', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text(
                'Avoid planting chickpeas in waterlogged or heavy clay soil, as it can lead to poor growth and disease.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Monitor the plants regularly for signs of pests and diseases and take prompt action to prevent damage.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Follow recommended spacing and planting depths to ensure optimal growth and yield.',
                style: TextStyle(fontSize: 16),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
