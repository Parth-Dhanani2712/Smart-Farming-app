import 'package:flutter/material.dart';

class cotton extends StatelessWidget {
  const cotton({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Cotton"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Image.asset(
                "assets/cotton.png",
                width: 100,
                height: 100,
              )),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Requirement', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),
              Text(
                'Selecting a Suitable Location:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Cotton grows best in warm climates with plenty of sunlight and well-draining soil. Choose a location with at least 6-8 hours of direct sunlight per day.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Soil Preparation:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Test the soil to ensure it has the right pH level (around 6.0 to 6.5). Add organic matter like compost or well-rotted manure to improve soil fertility and drainage.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Seed Selection:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Choose high-quality cotton seeds suited to your climate and soil type. Consult with local agricultural extension services for recommendations.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Planting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Plant cotton seeds when the soil temperature reaches at least 60°F (15°C). Space the seeds according to the recommended planting distance for your chosen variety.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Watering:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Cotton requires regular watering, especially during its early growth stages. Provide enough water to keep the soil consistently moist but not waterlogged.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Fertilization:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Apply fertilizer based on soil test recommendations or use a balanced fertilizer suitable for cotton. Follow application rates and timings according to local guidelines.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Weed Control:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the cotton field free from weeds, as they can compete with cotton plants for nutrients, water, and sunlight. Use mulch or manual weeding to control weeds.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pest and Disease Management:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Monitor the crop regularly for signs of pests and diseases. Use integrated pest management (IPM) strategies, such as using beneficial insects, crop rotation, and judicious use of pesticides.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pruning and Thinning:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Thin out overcrowded plants and prune excess growth to promote better airflow and light penetration, reducing the risk of diseases.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Harvest cotton when the bolls are fully mature and have split open. Use mechanical or hand-picking methods, depending on the scale of cultivation.',
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Precautions and Requirements', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),
              Text(
                'Climate:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Cotton requires a warm climate with a frost-free growing season. Ensure that the temperatures remain within the suitable range for cotton growth throughout the growing season.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pest and Disease Management:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Regular monitoring and timely intervention are crucial to prevent pest and disease outbreaks. Use pesticides sparingly and follow safety guidelines.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Water Management:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Avoid overwatering or underwatering, as both can lead to stress and reduced yield. Use irrigation methods that promote efficient water use, such as drip irrigation or furrow irrigation.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Soil Health:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Maintain soil fertility through proper fertilization and organic matter addition. Soil testing helps in determining nutrient deficiencies and adjusting fertilizer applications accordingly.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting Equipment:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'If growing cotton on a larger scale, invest in proper harvesting equipment such as cotton pickers or strippers for efficient and timely harvesting.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Market Research:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Before planting, consider market conditions and demand for cotton to ensure a profitable harvest. Stay informed about pricing trends and market fluctuations.',
                style: TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
