import 'package:flutter/material.dart';

class musterd extends StatelessWidget {
  const musterd({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Mustered"),),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Image.asset(
                    "assets/pepper.png",
                    width: 100,
                    height: 100,
                  )),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Requirement', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text(
                'Select a Variety:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Choose a mustard variety suitable for your climate and purpose (e.g., culinary or oil production).',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Prepare the Soil:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Mustard grows well in well-draining, fertile soil with a pH between 6.0 and 7.5.',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'Prepare the soil by tilling it to a depth of 6-8 inches and adding organic matter like compost.',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'Sow the Seeds:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Sow mustard seeds directly in the garden bed or containers. Plant them 1/4 to 1/2 inch deep and 1 inch apart in rows spaced about 6 inches apart.',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'Water the soil lightly after sowing to help the seeds germinate.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Watering:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the soil consistently moist but not waterlogged during the germination and growing phases.',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'Water the plants regularly, especially during dry spells, to promote healthy growth.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Fertilization:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Apply a balanced fertilizer according to the manufacturer\'s instructions when the plants are about 6 inches tall.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Weeding and Thinning:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Remove weeds regularly to reduce competition for nutrients and water.',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'Thin the mustard plants if they are too close together, leaving about 6-8 inches between plants.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pest and Disease Control:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Monitor the plants for pests like aphids, flea beetles, and caterpillars. Use organic pest control methods if necessary.',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'Prevent diseases like damping-off by maintaining good air circulation and avoiding overwatering.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Harvest mustard greens when they reach the desired size, usually around 4-6 inches tall. Cut the leaves just above the soil level.',
                style: TextStyle(fontSize: 16),
              ),
              Text(
                'For mustard seeds, allow the plants to mature fully, and harvest the seed pods when they turn brown and dry.',
                style: TextStyle(fontSize: 16),
              ),

              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Precautions and Requirements', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text(
                "Precautions:\n"
                    "- Avoid overwatering, as mustard plants are susceptible to root rot in waterlogged soil.\n"
                    "- Protect young plants from extreme heat or cold, as they prefer moderate temperatures.\n"
                    "- Monitor for pests and diseases regularly to prevent infestations and damage.\n\n"
                    "Requirements:\n"
                    "- Sunlight: Mustard plants prefer full sun but can tolerate partial shade.\n"
                    "- Water: Provide regular watering to keep the soil moist but not waterlogged.\n"
                    "- Soil: Well-draining, fertile soil with a pH between 6.0 and 7.5 is ideal.\n"
                    "- Space: Provide adequate spacing between plants to allow for healthy growth and air circulation.",
              style: TextStyle(fontSize: 16),),

            ],
          ),
        ),
      ),
    );
  }
}
