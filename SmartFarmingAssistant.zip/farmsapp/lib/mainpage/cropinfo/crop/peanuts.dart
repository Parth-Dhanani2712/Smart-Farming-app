import 'package:flutter/material.dart';

class peanut extends StatelessWidget {
  const peanut({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Peanuts"),),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Image.asset(
                    "assets/peanut.png",
                    width: 100,
                    height: 100,
                  )),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Requirement', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text(
                'Choose the Right Location:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peanuts require full sun and well-drained soil. Choose a location with at least 6-8 hours of sunlight daily.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Prepare the Soil:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Ensure the soil is loose, well-drained, and slightly acidic (pH around 5.8-6.2).\n'
                    'Add organic matter like compost or aged manure to improve soil fertility.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Select Peanut Varieties:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Choose a peanut variety suitable for your climate. There are several types, such as Virginia, Spanish, and Valencia.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Planting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Plant peanuts after the last frost date when the soil temperature reaches at least 65°F (18°C).\n'
                    'Space the peanut seeds about 8-12 inches apart in rows, with rows spaced about 24-36 inches apart.\n'
                    'Plant the seeds 1-2 inches deep with the pointed end facing downwards.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Watering:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the soil consistently moist but not waterlogged during the growing season.\n'
                    'Water deeply, especially during dry periods.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Fertilizing:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Use a balanced fertilizer before planting, following the instructions on the package.\n'
                    'Avoid excessive nitrogen as it can promote foliage growth over pod development.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Weeding and Mulching:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the area around the peanut plants weed-free to reduce competition for nutrients and water.\n'
                    'Mulch with straw or other organic material to conserve moisture and suppress weeds.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pest and Disease Control:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Monitor for pests like aphids, cutworms, and nematodes. Use organic or chemical controls as needed.\n'
                    'Watch for diseases like leaf spot and rust, and promptly treat with fungicides if necessary.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peanuts are ready for harvest when the plants begin to yellow and the pods mature (about 120-150 days after planting).\n'
                    'Carefully dig up the plants, shake off excess soil, and hang them to dry in a warm, well-ventilated area for about 2-4 weeks.\n'
                    'Once dried, remove the peanuts from the plants and store them in a cool, dry place.',
                style: TextStyle(fontSize: 16),
              ),

              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Precautions and Requirements', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text(
                'Peanut Allergies:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Be cautious if you or anyone around you has peanut allergies. Take necessary precautions to avoid contact with allergens.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Soil Drainage:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Ensure good soil drainage to prevent waterlogging, which can lead to root rot and other problems.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pest and Disease Management:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Regularly inspect plants for pests and diseases, and take appropriate action to control them.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Proper Spacing:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Follow recommended spacing guidelines to allow plants enough room to grow and develop.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Watering Practices:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Avoid overwatering, as this can lead to fungal diseases. Use a drip irrigation system or water at the base of plants to keep foliage dry.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting Safety:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Wear gloves and protective clothing when harvesting and handling peanuts, especially if allergic reactions are a concern.',
                style: TextStyle(fontSize: 16),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
