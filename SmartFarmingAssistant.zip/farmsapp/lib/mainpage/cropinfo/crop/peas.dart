import 'package:flutter/material.dart';

class peas extends StatelessWidget {
  const peas({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Peas"),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Image.asset(
                "assets/pea.png",
                width: 100,
                height: 100,
              )),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Requirement', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),
              Text(
                'Select a Variety:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Choose a pea variety suitable for your climate and space, such as snap peas, snow peas, or shelling peas.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Choose the Right Location:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peas thrive in cool weather. Select a sunny location with well-drained soil.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Prepare the Soil:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Ensure the soil is fertile, loose, and rich in organic matter. Add compost or aged manure to improve soil quality.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Planting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Plant pea seeds directly into the soil in early spring, about 1 inch deep and 2-3 inches apart. If using rows, space rows about 18-24 inches apart.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Watering:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the soil consistently moist but not waterlogged. Water regularly, especially during dry periods.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Support:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peas are climbing plants. Provide support such as trellises, stakes, or netting for them to climb as they grow.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Fertilizing:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peas generally don\'t require much fertilizer if the soil is already rich. However, you can use a balanced fertilizer if needed.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Weeding:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the area around pea plants weed-free to prevent competition for nutrients and water.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Harvest peas when the pods are plump and the peas inside are tender. Pick regularly to encourage continuous production.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Precautions:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Avoid Overwatering: Peas prefer moist soil but can suffer from root rot if the soil is waterlogged.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Watch for Pests:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep an eye out for pests like aphids, pea moths, and pea weevils. Use organic pest control methods if necessary.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Monitor Diseases:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peas can be susceptible to diseases like powdery mildew and pea blight. Practice good garden hygiene and use disease-resistant varieties if available.',
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Precautions and Requirements', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),
              Text(
                'Sunlight:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peas need at least 6-8 hours of sunlight daily for optimal growth and pod development.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Soil:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Well-draining, fertile soil with a pH around 6.0-7.5 is ideal for peas.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Water:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Regular watering to keep the soil consistently moist, especially during dry spells.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Support Structures:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peas require support for climbing, such as trellises, stakes, or netting.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Temperature:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Peas prefer cooler temperatures, so plant them in early spring or late summer for a fall harvest in warmer climates.',
                style: TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
