import 'package:flutter/material.dart';

class rice extends StatelessWidget {
  const rice({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Rice"),),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child: Image.asset(
                    "assets/rice.png",
                    width: 100,
                    height: 100,
                  )),
              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Requirement', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),
              const SizedBox(height: 20),
              Text(
                'Site Selection:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Choose a location with full sun exposure.\n'
                    'Ensure the soil is well-drained and rich in nutrients, particularly nitrogen.\n'
                    'Rice requires plenty of water, so the site should be near a reliable water source like a river, lake, or well.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10), // Add some spacing between sections
              Text(
                'Preparation:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Prepare the soil by plowing or tilling to a depth of about 6-8 inches.\n'
                    'Incorporate organic matter such as compost or well-rotted manure to improve soil fertility.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Seed Selection and Preparation:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Select high-quality rice seeds from a reputable supplier.\n'
                    'Pre-germinate the seeds by soaking them in water for about 24 hours before planting.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Planting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Create rows or seed beds for planting.\n'
                    'Plant the pre-germinated seeds at a depth of about 1-2 inches and space them according to the variety\'s recommendations.\n'
                    'Keep the soil consistently moist during the germination period.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Water Management:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Once the seedlings emerge, maintain a shallow layer of water (1-2 inches) in the rice paddies.\n'
                    'Gradually increase the water depth as the plants grow, aiming for about 4-6 inches of water during the vegetative stage.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Fertilization:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Apply nitrogen-rich fertilizers during different growth stages, such as nitrogen during the vegetative stage and potassium and phosphorus during flowering and grain filling.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Weed Control:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Keep the rice paddies weed-free by hand weeding or using herbicides as needed.\n'
                    'Be careful not to damage the rice plants during weeding.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Pest and Disease Management:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Monitor for pests such as rice blast, stem borers, and weeds.\n'
                    'Use integrated pest management practices, including biological controls and chemical treatments if necessary.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Harvesting:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Harvest the rice when the grains are fully mature and have turned golden yellow.\n'
                    'Cut the rice plants close to the ground and allow them to dry in the field for a few days before threshing.',
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 10),
              Text(
                'Post-Harvest Handling:',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Thresh the rice to separate the grains from the straw.\n'
                    'Dry the rice grains thoroughly to reduce moisture content and prevent mold growth.\n'
                    'Store the dried rice in a cool, dry place in airtight containers to maintain quality.',
                style: TextStyle(fontSize: 16),
              ),

              const SizedBox(height: 20),
              RichText(
                  text: TextSpan(
                      text: 'Precautions and Requirements', // The text content
                      style: TextStyle(
                        // Style for the entire text
                        color: Colors.green[200],
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        // Add other text styles as needed
                      ))),

              Text("Ensure proper water management to avoid waterlogging or drought stress.\n"
                "Monitor for pests and diseases regularly and take prompt action if detected.\n"
                "Follow recommended fertilization practices to avoid nutrient deficiencies or excesses.\n"
                "Be mindful of environmental factors such as temperature and humidity, which can affect rice growth.\n",
                style: TextStyle(fontSize: 16),),
              
              Text("Suitable land with access to water.\n"
                  "High-quality rice seeds.\n"
                  "Tools and equipment for land preparation, planting, and harvesting (e.g., plows, seeders, harvesters).\n"
                  "Fertilizers and pest control products as needed.\n"
                   "Knowledge of rice cultivation practices and local growing conditions.\n",
                style: TextStyle(fontSize: 16),),

            ],
          ),
        ),
      ),
    );
  }
}
