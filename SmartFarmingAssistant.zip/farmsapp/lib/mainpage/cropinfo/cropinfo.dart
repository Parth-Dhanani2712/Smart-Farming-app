import 'package:flutter/material.dart';

import 'crop/castor.dart';
import 'crop/chickpea.dart';
import 'crop/cotton.dart';
import 'crop/musters.dart';
import 'crop/peanuts.dart';
import 'crop/peas.dart';
import 'crop/rice.dart';
import 'crop/soybean.dart';
import 'crop/wheat.dart';

final List<List<String>> _cropItems = [
  ["Wheat", "assets/wheat.png"],
  ["Rice", "assets/rice.png"],
  ["Chickpeas", "assets/chickpeas.png"],
  ["Peanuts", "assets/peanut.png"],
  ["Cotton", "assets/cotton.png"],
  ["Peas", "assets/pea.png"],
  ["Castor", "assets/seed.png"],
  ["Soybean", "assets/soybean.png"],
  ["Mustered", "assets/pepper.png"],
];

class cropinfo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Crop Information"),
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_outlined, size: 35),
        ),
      ),
      body: ListView.builder(
        itemCount: _cropItems.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8.0),
            child: GestureDetector(
              onTap: () {
                switch (index) {
                  case 0:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => wheat()));
                    break;
                  case 1:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => rice()));
                    break;
                  case 2:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => chickpea()));
                    break;
                  case 3:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => peanut()));
                    break;
                  case 4:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => cotton()));
                    break;
                  case 5:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => peas()));
                    break;
                  case 6:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => castor()));
                    break;
                  case 7:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => soybean()));
                    break;
                  case 8:
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => musterd()));
                    break;
                }
              },
                child:Card(
                  child: ListTile(
                    leading: Image.asset(
                      _cropItems[index][1],
                      width: 50,
                      height: 50,
                    ),
                    title: Text(_cropItems[index][0]),
                  ),
                ),
            ),
          );
        },
      ),
    );
  }
}

class CropDetailPage extends StatelessWidget {
  final String cropName;
  final String imagePath;

  const CropDetailPage({
    Key? key,
    required this.cropName,
    required this.imagePath,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Crop Detail"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              cropName,
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Image.asset(
              imagePath,
              width: 150,
              height: 150,
            ),
          ],
        ),
      ),
    );
  }
}
