import 'package:flutter/material.dart';
import '../market/pages/home_page.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: market(),
    );
  }
}

class market extends StatefulWidget {
  const market({super.key});

  @override
  State<market> createState() => _marketState();
}

class _marketState extends State<market> {
  @override
  Widget build(BuildContext context) {
    return Home();
  }
}
