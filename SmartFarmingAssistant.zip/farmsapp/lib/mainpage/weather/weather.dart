import 'package:farmsapp/mainpage/weather/pages/weather_page.dart';
import 'package:flutter/material.dart';

class weather extends StatelessWidget {
  const weather({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('weather Forecast'),
        ),
        body: WeatherPage()
      );
  }
}
